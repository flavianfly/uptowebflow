package com.fur.dao;

import java.util.List;

import com.fur.model.Category;

public interface CategoryDAO {
 
	
	public int insertRow(Category cate);

 public List getList();

 public Category getRowById(int id);

 public int updateRow(Category cate);

 public int deleteRow(int id);



}

