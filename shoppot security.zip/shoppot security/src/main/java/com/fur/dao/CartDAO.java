/*package com.fur.dao;

import java.util.List;

import com.fur.model.Cart;

public interface CartDAO {
 
	
	public int insertRow(Cart car);

 public List getList();

 public Cart getRowById(int id);

 public int updateRow(Cart car);

 public int deleteRow(int id);



}

*/