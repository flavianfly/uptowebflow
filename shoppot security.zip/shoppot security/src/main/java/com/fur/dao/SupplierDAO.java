package com.fur.dao;

import java.util.List;

import com.fur.model.Supplier;

public interface SupplierDAO {
 
	
	public int insertRow(Supplier supp);

 public List getList();

 public Supplier getRowById(int id);

 public int updateRow(Supplier supp);

 public int deleteRow(int id);



}

