/*package com.fur.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fur.dao.CartDAO;
import com.fur.model.Cart;



@Service("cartService")

public class CartserviceImpl implements CartService {
    
	@Autowired
	 CartDAO cartDAO;

	@Transactional(propagation = Propagation.SUPPORTS)
	 public int insertRow(Cart car) {
	  return cartDAO.insertRow(car);
	 }

	@Transactional(propagation = Propagation.SUPPORTS)
	 public List getList() {
	  return cartDAO.getList();
	 }

	@Transactional(propagation = Propagation.SUPPORTS)
	 public Cart getRowById(int id) {
	  return cartDAO.getRowById(id);
	 }

	@Transactional(propagation = Propagation.SUPPORTS)
	 public int updateRow(Cart car) {
	  return cartDAO.updateRow(car);
	 }

	@Transactional(propagation = Propagation.SUPPORTS)
	 public int deleteRow(int id) {
	  return cartDAO.deleteRow(id);
	 }
}*/