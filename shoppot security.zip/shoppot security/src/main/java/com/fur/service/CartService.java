/*package com.fur.service;

import java.util.List;

import com.fur.model.Cart;

public interface CartService {
 
 public int insertRow(Cart car);

 public List getList();

 public Cart getRowById(int id);

 public int updateRow(Cart car);

 public int deleteRow(int id);

}

*/